export interface IBandaRock {
    id: number,
    nombre: string,
    acercaDe: string,
    album: string,
    urlBanda: string,
    urlAlbum: string
}